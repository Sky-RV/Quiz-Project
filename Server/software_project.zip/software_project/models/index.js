module.exports = {
    uniModel: require("./university"),
    userModel: require("./user"),
   
}