
let userType = ['administor','professor','student']

module.exports = {userType}
