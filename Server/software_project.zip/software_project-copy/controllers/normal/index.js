module.exports = {
    UniversityController: require("./university"),
    UserController: require("./user"),
    AuthController: require("../auth/login"),
    CourseController:require("./course")
}